public class Main {
    public static void main(String[] args) {

        class Persona {
            private int edad;
            private int teléfono;
            private String nombre;

            public void setEdad(int edad) {
                this.edad = edad;
            }
            public void setTeléfono(int teléfono) {
                this.teléfono = teléfono;
            }
            public void setNombre(String nombre) {
                this.nombre = nombre;
            }

            public int getEdad() {
                return this.edad;
            }
            public int getTeléfono() {
                return this.teléfono;
            }
            public String getNombre() {
                return this.nombre;
            }
        }

        Persona persona1 = new Persona();
        persona1.setEdad(18);
        persona1.setTeléfono(678678678);
        persona1.setNombre("Raul");

        int edad = persona1.getEdad();
        int teléfono = persona1.getTeléfono();
        String nombre = persona1.getNombre();

        System.out.println(edad);
        System.out.println(teléfono);
        System.out.println(nombre);






    }
}